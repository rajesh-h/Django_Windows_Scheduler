from django.apps import AppConfig


class Windows_schedulerConfig(AppConfig):
    name = 'windows_scheduler'
